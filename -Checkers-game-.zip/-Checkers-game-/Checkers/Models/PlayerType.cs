﻿namespace Checkers.Services
{
    public enum PlayerType
    {
        None = 0,
        Red,
        White
    }
}
