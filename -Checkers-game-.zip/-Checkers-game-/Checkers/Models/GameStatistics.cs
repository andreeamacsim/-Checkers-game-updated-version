﻿namespace Checkers.Models
{
    public class GameStatistics
    {
        public int WhiteWins { get; set; }
        public int RedWins { get; set; }
        public int MaxPiecesRemaining { get; set; }
        
    }
}
