﻿namespace Checkers.Models
{
    public enum CheckerTypes
    {
        None,
        RedPawn,
        RedKing,
        WhitePawn,
        WhiteKing
    }
}
