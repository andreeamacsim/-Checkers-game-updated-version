﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkers.Helpers
{
    public static class SessionData
    {
        public static string CurrentUserName { get; set; }
    }
}
